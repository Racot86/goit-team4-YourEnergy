# goit-js-hw-01

**Variables and types. The basics of functions.**

Виклик на сторінку https://essencemaks.github.io/goit-js-hw-01/

# **Задача 1. Замовлення дроїдів**

Розв'язок задачі: [task-1.js](./js/task-1.js)

---

# **Задача 2. Доставка товару**

Розв'язок задачі: [task-2.js](./js/task-2.js)

---

# **Задача 3. Ширина елемента**

Розв'язок задачі: [task-3.js](./js/task-3.js)

---
