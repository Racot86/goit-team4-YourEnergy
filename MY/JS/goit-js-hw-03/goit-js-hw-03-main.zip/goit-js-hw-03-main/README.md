# goit-js-hw-03
#**Масиви**
---

Перехід на сторінку: <a href="https://essencemaks.github.io/goit-js-hw-03/" target="_blank">https://essencemaks.github.io/goit-js-hw-03/</a>


# **Задача 1. Генератор slug**

Розв'язок задачі: [task-1.js](./js/task-1.js)

---

# **Задача 2. Композиція масивів**

Розв'язок задачі: [task-2.js](./js/task-2.js)

---

# **Задача 3. Фільтрація масиву чисел**

Розв'язок задачі: [task-3.js](./js/task-3.js)

---
