<h1 align="center">goit-js-hw-04</h1>
<h1 align="center" style="color : yellowgreen" > Масиви та методи об'єкта</h2>

$\color{rgb(154, 205, 50)}{\textsf{━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━}}$

---

Перехід на сторінку: <a href="https://essencemaks.github.io/goit-js-hw-04/" target="_blank">https://essencemaks.github.io/goit-js-hw-04/</a>

# **Задача 1. Пакування товарів**

Розв'язок задачі: [task-1.js](./js/task-1.js)

---

# **Задача 2. Розрахунок калорій**

Розв'язок задачі: [task-2.js](./js/task-2.js)

---

# **Задача 3. Профіль гравця**

Розв'язок задачі: [task-3.js](./js/task-3.js)

---
