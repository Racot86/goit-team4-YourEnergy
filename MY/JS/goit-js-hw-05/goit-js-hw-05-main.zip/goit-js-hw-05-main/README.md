<h1 align="center">goit-js-hw-05</h1>
<h1 align="center" style="color : yellowgreen" >**Перебераючі методи масивів**</h2>

$\color{rgb(154, 205, 50)}{\textsf{━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━}}$

Перехід на сторінку: <a href="https://essencemaks.github.io/goit-js-hw-05/" target="_blank">https://essencemaks.github.io/goit-js-hw-05/</a>

# **Задача 1. Імена користувачів**

Розв'язок задачі: [task-1.js](./js/task-1.js)

---

# **Задача 2. Користувачі з другом**

Розв'язок задачі: [task-2.js](./js/task-2.js)

---

# **Задача 3. Сортування за кількістю друзів**

Розв'язок задачі: [task-3.js](./js/task-3.js)

---

# **Задача 4. Загальний баланс**

Розв'язок задачі: [task-4.js](./js/task-4.js)

---
