<h1 align="center">goit-js-hw-06</h1>
<h2 align="center">ООП. Класи</h2>
<hr style="border: 1px solid yellowgreen">
---

Перехід на сторінку: <a href="https://essencemaks.github.io/goit-js-hw-06/" target="_blank">https://essencemaks.github.io/goit-js-hw-06/</a>

# **Задача 1. Акаунт користувача**

Розв'язок задачі: [task-1.js](./js/task-1.js)

---

# **Задача 2. Склад**

Розв'язок задачі: [task-2.js](./js/task-2.js)

---

# **Задача 3. Конструктор рядків**

Розв'язок задачі: [task-3.js](./js/task-3.js)

---