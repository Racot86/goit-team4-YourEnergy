<h1 align="center">goit-js-hw-07</h1>
<h2 align="center">Модель DOM. Події</h2>
<hr style="border: 1px solid yellowgreen">
---

Перехід на сторінку: <a href="https://essencemaks.github.io/goit-js-hw-06/" target="_blank">https://essencemaks.github.io/goit-js-hw-06/</a>

# **Завдання 1. HTML містить список категорій ul#categories**

Розв'язок задачі: [task-1.js](./js/task-1.js)

---

# **Завдання 2. HTML містить список ul.gallery**

Розв'язок задачі: [task-2.js](./js/task-2.js)

---

# **Завдання 3. Скрипт input#name**

Розв'язок задачі: [task-3.js](./js/task-3.js)

---
# **Завдання 4. Скрипт управління формою логіна**

Розв'язок задачі: [task-1.js](./js/task-4.js)

---

# **Завдання 5. Скрипт, зміни кольору фону елемента <body>**

Розв'язок задачі: [task-2.js](./js/task-5.js)

---

# **Завдання 6. Скрипт створення й очищення колекції елементів**

Розв'язок задачі: [task-3.js](./js/task-6.js)

---

